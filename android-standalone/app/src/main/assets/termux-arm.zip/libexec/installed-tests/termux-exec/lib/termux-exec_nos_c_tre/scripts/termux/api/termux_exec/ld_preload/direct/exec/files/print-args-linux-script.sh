#!/data/data/com.etwqfd.agentetc//bin/sh

echo "$@"
